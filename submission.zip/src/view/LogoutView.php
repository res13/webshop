<?php

class LogoutView extends View
{

    public function render(LanguageController &$languageController, $errorMessage = null)
    {
    }
}